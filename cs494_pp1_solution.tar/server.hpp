#pragma once
#include "udpsocket.hpp"
#include "StopWaitServer.hpp"
#include <fstream>

#define MAX_PACKET_SIZE 1000
#define ACK_TIMEOUT 400
#define INIT_SEQNUM 0
