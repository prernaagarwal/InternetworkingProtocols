#pragma once
#include "udpsocket.hpp"
#include "StopWaitClient.hpp"
#include <fstream>

#define INIT_SEQNUM 0
